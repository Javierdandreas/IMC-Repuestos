import { z } from "zod";
import { validateWithSchema, uppercaseNonEmptyStringSchema } from "./common";

/**
 * Esquema para la creación de un lote de series.
 * Múltiples números de serie para un solo producto id.
 */
export const createSeriesPayloadSchema = z.object({
  id_producto: z.number().int().positive("El ID del producto debe ser válido"),
  numeros_serie: z.array(uppercaseNonEmptyStringSchema)
    .min(1, "Debe ingresar al menos un número de serie")
    .max(200, "No puede ingresar más de 200 series a la vez"),
});

export type CreateSeriesPayload = z.infer<typeof createSeriesPayloadSchema>;

export function validateCreateSeriesPayload(body: any): CreateSeriesPayload {
  return validateWithSchema(createSeriesPayloadSchema, body);
}
